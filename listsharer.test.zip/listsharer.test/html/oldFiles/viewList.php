<?php
require_once("../scripts/sqlConnect.php");
require_once("../scripts/cleanData.php");

class Listobj{
	public $listID;
	public $code;
	public $name;
	public $lastViewed;
	public $entries;
}

class Entry{
	public $entryID;
	public $title;
	public $description;
	public $quantity;
	public $dateCreated;
	public $checked;
	public $tags;
	
	function toString() {		
		return "Entry#".$this->entryID." '".$this->title."'";
	}	
}

$dbc = createDefaultConnection("listsharer");

$list = new Listobj();
$list->code = cleanData_Alphanumeric($_GET["l"],8);
$list->entries = [];

//First up, lets just get basic info on the list

$stmt;
$query = "SELECT * FROM lists WHERE Code=?";
$stmt = $dbc->stmt_init();
$stmt->prepare($query);
$stmt->bind_param("i",$list->code);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_array();

if(!$row){
	$dbc->close();
	$stmt->close();
	echo "Error";
	exit();
}
$list->listID = $row["ListID"];
$list->name = $row["Name"];
$list->lastViewed = $row["LastViewed"];

echo "List Name: ".$list->name;
echo "<br>Last Viewed: ".$list->lastViewed;

//Now lets get all the entries

$stmt->close();
$query = "SELECT * FROM listentry WHERE ListID=?";
$stmt = $dbc->stmt_init();
$stmt->prepare($query);
$stmt->bind_param("i",$list->listID);
$stmt->execute();
$result = $stmt->get_result();
  //Or does it need to close here just once?
while ($entryIDRow = $result->fetch_array()){
	$stmt->close();
	$query = "SELECT * FROM entries WHERE EntryID=?";
	$stmt = $dbc->stmt_init();
	$stmt->prepare($query);
	$stmt->bind_param("i",$entryIDRow["EntryID"]);
	$stmt->execute();
	$entryResult = $stmt->get_result();
	
	$row = $entryResult->fetch_array();
	if(!$row){
		$dbc->close();
		$stmt->close();
		echo "Error";
		exit();
	}
	$entry = new Entry();
	$entry->entryID = $row["EntryID"];
	$entry->title = $row["Title"];
	$entry->description = $row["Description"];
	$entry->quantity = $row["Quantity"];
	$entry->dateCreated = $row["DateCreated"];
	$entry->checked = $row["Checked"];
	array_push($list->entries, $entry);
}

foreach ($list->entries as &$entry) {
	echo "<br>".$entry->toString();
}

$dbc->close();$stmt->close();
?>