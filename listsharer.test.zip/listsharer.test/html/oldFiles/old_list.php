<?php
require_once("../scripts/sqlConnect.php");
require_once("../scripts/cleanData.php");

class Listobj{
	public $listID;
	public $code;
	public $name;
	public $lastViewed;
	public $entries;
}

$dbc = createDefaultConnection("listsharer");

$error = false;

$list = new Listobj();
$list->code = cleanData_Alphanumeric($_GET["l"],8);
$list->entries = [];

$stmt = $dbc->stmt_init();
$stmt->prepare("SELECT * FROM lists WHERE Code=?");
$stmt->bind_param("s",$list->code);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_array();
$stmt->free_result(); $stmt->close();

if(!$row){
	$error = true;
}else{
	$list->listID = $row["ListID"];
	$list->name = $row["Name"];
	$list->lastViewed = $row["LastViewed"];
}

$dbc->close();
?>

<html>
<head>

	<?php 
		if($error){ echo "<title>Error</title>"; exit;}
		else{ 
			echo "<title>".$list->name."</title>"; 
			
			echo "<script> var listcode = '".$list->code."'; var listname = '".$list->name."';</script>";
			
			echo "<script src=\"scripts/zepto.min.js\"></script>";
			echo "<script src=\"scripts/list.js\"></script>";
		}
		
	?>
</head>

<body>

	<div id="listName">
		<script>
			if(listname){
				$("#listName").append("List: "+listname);
			}
		</script>
	</div>
	<div id="test" style="display:none;"> 
		<div id="Entry0" style="width:100%; height:100px; background-color:#dddddd;">
			<input id="Entry0Checked" type="checkbox">
			<input id="Entry0Quantity" type="number" style="width:50px" value="1">
			<input id="Entry0Title" type="text" value="Title">
			<input id="Entry0Tags" type="text" value="Tags">
			Date
			<textarea id="Entry0Description" rows="2" cols="50">Description</textarea>
			<button id="Entry0BtnEdit" type="button">Edit</button>
			<button id="Entry0BtnRemove" type="button">Remove</button>
		</div>
	</div>
	
	<div id="entriesDiv"></div>
	
	<br><br>
	<div id="EntryAdd" style="width:100%; height:100px; background-color:#dddddd;">
		<h3>Add Entry:</h3>
		<input id="EntryAddQuantity" type="number" style="width:50px" value="1">
		<input id="EntryAddTitle" type="text" value="Title">
		<input id="EntryAddTags" type="text" value="Tags">
		Date
		<textarea id="EntryAddDescription" rows="2" cols="50">Description</textarea>
		<button id="EntryAddBtn" type="button" onclick="addEntry()">Add</button>
	</div>
	
</body>

</html>