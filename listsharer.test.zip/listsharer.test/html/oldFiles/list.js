function createEntryDiv(e){
	var elm = "<div id=\"Entry"+e["entryID"]+"\" style=\"width:100%; height:100px; margin-top:10px; background-color:#dddddd;\">";
	elm +='<input id="Entry'+e["entryID"]+'Checked" type="checkbox" '+ ((e["checked"])?"checked":"") +' ">';
	elm +='<input id="Entry'+e["entryID"]+'Quantity" type="number" style="width:50px" value="'+e["quantity"]+'">';
	elm +='<input id="Entry'+e["entryID"]+'Title" type="text" value="'+e["title"]+'">';
	elm +='<input id="Entry'+e["entryID"]+'Tags" type="text" value="'+e["tags"]+'">';
	elm +=e["dateCreated"];
	elm +='<textarea id="Entry'+e["entryID"]+'Description" rows="2" cols="50">'+e["description"]+'</textarea>';
	
	elm+='<button id="Entry'+e["entryID"]+'BtnEdit" type="button" onclick="editEntry('+e["entryID"]+')">Edit</button>';
	elm+='<button id="Entry'+e["entryID"]+'BtnRemove" type="button" onclick="removeEntry('+e["entryID"]+')">Remove</button>';
	
	elm += '</div>';
	
	$("#entriesDiv").append(elm);
}
function createEntryDivStrict(id, quantity,title,tags,date,description){
	var elm = "<div id=\"Entry"+id+"\" style=\"width:100%; height:100px; margin-top:10px; background-color:#dddddd;\">";
	elm +='<input id="Entry'+id+'Checked" type="checkbox">';
	elm +='<input id="Entry'+id+'Quantity" type="number" style="width:50px" value="'+quantity+'">';
	elm +='<input id="Entry'+id+'Title" type="text" value="'+title+'">';
	elm +='<input id="Entry'+id+'Tags" type="text" value="'+tags+'">';
	elm +=date;
	elm +='<textarea id="Entry'+id+'Description" rows="2" cols="50">'+description+'</textarea>';
	
	elm+='<button id="Entry'+id+'BtnEdit" type="button" onclick="editEntry('+id+')">Edit</button>';
	elm+='<button id="Entry'+id+'BtnRemove" type="button" onclick="removeEntry('+id+')">Remove</button>';
	
	elm += '</div>';
	
	$("#entriesDiv").append(elm);
}

function addEntry(){
	
	var title = document.getElementById('EntryAddTitle').value;
	var description = document.getElementById('EntryAddDescription').value;
	var quantity = document.getElementById('EntryAddQuantity').value;
	var tags = document.getElementById('EntryAddTags').value;
	
	ajaxAddEntry(listcode,title,description,quantity,tags, function(out){ //Remember listcode is already defined somewhere else
		var results = JSON.parse(out);
		if(results["success"] == 0 || !results["entry"]){
			alert(results["error"]);
			return;
		}else{
			createEntryDiv(results["entry"]);
			///TODO: Clear add box
		}
		
	});
}
function editEntry(id){
	var title = document.getElementById('Entry'+id+'Title').value;
	var description = document.getElementById('Entry'+id+'Description').value;
	var quantity = document.getElementById('Entry'+id+'Quantity').value;
	var checked = (document.getElementById('Entry'+id+'Checked').checked ? 1:0);
	var tags = document.getElementById('Entry'+id+'Tags').value;
	
	//code,entry,title,desc,quant,checked,tags, handleData
	ajaxEditEntry(listcode,id,title,description,quantity,checked,tags, function(out){ //Remember listcode is already defined somewhere else
		var results = JSON.parse(out);
		if(results["success"] == 0 || !results["entryID"]){
			alert(results["error"]);
			document.getElementById("Entry"+id).style.opacity = ".75";
			return;
		}else{
			//createEntryDiv(results["entry"]);
			document.getElementById("Entry"+id).style.opacity = "1";
		}
		
	});
}


///TODO: Protect against button mashing. If request is already being processed, do not allow another one
function removeEntry(id){
	ajaxRemoveEntry(listcode,id, function(out){
		var results = JSON.parse(out);
		if(results["success"] == 0){
			document.getElementById("Entry"+id).style.opacity = "1";
			alert(results["error"]);
			return;
		}else{
			removeElement("Entry"+id);
		}
		
	});
}

function loadList(code){	
	ajaxLoadList(code, function(output){
		var results = JSON.parse(output);
		
		//$("#loading").hide();
		
		if(results["success"] == 0 || !results["entries"]){
			alert(results["error"]);
			return;
		}
		
		var entries = results["entries"];
		
		var i;
		for (i = 0; i < entries.length; i++) {
			createEntryDiv(entries[i]);
			addEntry(entries[i]["entryID"],entries[i]["title"],entries[i]["tags"],entries[i]["description"],entries[i]["dateCreated"]);
		}
		
	});
}


	
function ajaxLoadList(code, handleData) {
	$.ajax({
		url:"/backend/getEntries.php",
		type:'POST',
		data:
		{
			code:code,
		},beforeSend: function() {
			//$("#loading").show();
		},success:function(data) {
			handleData(data); 
		},error: function(){
			//$("#loading").hide();
			alert("Request Failed");
		},
		timeout: 10000
	});
}
function ajaxRemoveEntry(code,entryID, handleData) {
	$.ajax({
		url:"/backend/removeEntry.php",
		type:'POST',
		data:
		{
			code:code,
			entryID:entryID
		},beforeSend: function() {
			document.getElementById("Entry"+entryID).style.opacity = "0.5";
		},success:function(data) {
			handleData(data); 
		},error: function(){
			document.getElementById("Entry"+entryID).style.opacity = "1";
			alert("Request Failed");
		},
		timeout: 10000
	});
}
function ajaxAddEntry(code,title,desc,quant,tags, handleData) {
	$.ajax({
		url:"/backend/addEntry.php",
		type:'POST',
		data:
		{
			code:code,
			title:title,
			desc:desc,
			quant:quant,
			tags:tags
		},beforeSend: function() {
			createEntryDivStrict("Temp", quant, title, tags, new Date(), desc);
			
			document.getElementById("EntryTemp").style.opacity = "0.5";
		},success:function(data) {
			removeElement("EntryTemp");
			handleData(data);
		},error: function(){
			removeElement("EntryTemp");
			alert("Request Failed");
		},
		timeout: 10000
	});
}

function ajaxEditEntry(code,entry,title,desc,quant,checked,tags, handleData) {
	$.ajax({
		url:"/backend/editEntry.php",
		type:'POST',
		data:
		{
			code:code,
			entry:entry,
			title:title,
			desc:desc,
			quant:quant,
			checked:checked,
			tags:tags
		},beforeSend: function() {
			document.getElementById("Entry"+entry).style.opacity = "0.5";
		},success:function(data) {
			handleData(data); 
		},error: function(){
			document.getElementById("Entry"+entry).style.opacity = ".75";
			alert("Request Failed");
		},
		timeout: 10000
	});
}


function removeElement(id){
	var element = document.getElementById(id);
	element.parentNode.removeChild(element);
}

$( document ).ready(function() {
    loadList(listcode);
});