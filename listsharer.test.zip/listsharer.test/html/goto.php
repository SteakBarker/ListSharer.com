<html>
<head>
	<title>Listsharer.com</title>
</head>


<body>
	<h1> Goto a list </h1>
	<p>Type in the list code, and goto the list</p>
	
	<input id="listcode" type="text" value="List Code"  onfocus="this.value=''">
	<button id="goBtn" type="button" onclick="goto()">Go!</button>
	
	<script>
		function goto(){
			window.location.href = "list.php?l="+ (document.getElementById('listcode').value).toUpperCase();
		}
	</script>
	
</body>
</html>