<?php
require_once("../scripts/sqlConnect.php");
require_once("../scripts/cleanData.php");

class Listobj{
	public $listID;
	public $code;
	public $name;
	public $lastViewed;
	public $entries;
}

$dbc = createDefaultConnection("listsharer");

$error = false;

$list = new Listobj();
$list->code = cleanData_Alphanumeric($_GET["l"],8);
$list->entries = [];

$stmt = $dbc->stmt_init();
$stmt->prepare("SELECT * FROM lists WHERE Code=?");
$stmt->bind_param("s",$list->code);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_array();
$stmt->free_result(); $stmt->close();

if(!$row){
	$error = true;
}else{
	$list->listID = $row["ListID"];
	$list->name = $row["Name"];
	$list->lastViewed = $row["LastViewed"];
}

$dbc->close();
?>

<html>
<head>
	<link rel="stylesheet" href="css/newlist.css">
	<link rel="stylesheet" href="css/overlay.css">
	<?php 
		if($error){ echo "<title>Error</title>"; exit;}
		else{ 
			echo "<title>".$list->name."</title>"; 
			
			echo "<script> var listcode = '".$list->code."'; var listname = '".$list->name."';</script>";
			
			echo "<script src=\"scripts/zepto.min.js\"></script>";
			echo "<script src=\"scripts/list/list.js\"></script>";
			echo "<script src=\"scripts/list/list_EditEntry.js\"></script>";
			echo "<script src=\"scripts/list/list_Tags.js\"></script>";
			echo "<script src=\"scripts/list/list_AddEntry.js\"></script>";
			echo "<script src=\"scripts/list/list_LoadList.js\"></script>";
			echo "<script src=\"scripts/list/list_Check.js\"></script>";
			echo "<script src=\"scripts/list/list_Remove.js\"></script>";
			echo "<script src=\"scripts/tips.js\"></script>";
		}
		
	?>
</head>

<body>
	<div id="loadingIcon" style="display:none"><img src="images/loading.gif"></div>

	<div class="overlay" id="loadingOverlay" style="display:none">
	</div>
	
	<div class="overlay" id="editOverlay" style="display:none">
		<div class="entryDiv" id="editEntry">
			<input id="editChecked" type="checkbox">
			<input id="editTitle" type="text" value="Title">
			<input id="editTags" type="text" value="Tags">
			<input id="editDesc" type="text" value="Desc">
			<button id="EntryConfirmBtn" type="button" onclick="confirmEdit()">Confirm</button>
			<button id="EntryCancelBtn" type="button" onclick="cancelEdit()">Cancel</button>
		</div>
	</div>
	
	<div>
		<h3 id="listName">
		<h3 id="listCode">
		
		</h3>
		<hr>
		<script>
			if(listname){
				document.getElementById("listName").innerHTML = listname;
				document.getElementById("listCode").innerHTML = listcode;
			}
		</script>
	</div>
	
	<div id="search">
		<h3 style="display:inline-block"> Search: </h3>
		<div id="selectedTags">
			
		</div>
	</div>
	<div id="tags">
		<h3 style="display:inline-block"> Tags: </h3>
		<div id="allTags">
			
		</div>
	</div>
	
	<hr>
	
	<div id="listContainer">
			
	</div>
	
	<div id="entriesDiv"></div>
	
	<br><br>
	<div id="EntryAdd" style="width:100%; height:100px; background-color:#dddddd;">
		<h3>Add Entry:</h3>
		<input id="EntryAddTitle" type="text" value="Title">
		<input id="EntryAddTags" type="text" value="Tags" onfocus="showTip('tagTip')" onblur="hideTip('tagTip')">
			<div class="tip" id="tagTip" style="display:none"> Seperate tags by commas </div>
		<textarea id="EntryAddDesc" rows="2" cols="50">Description</textarea>
		<button id="EntryAddBtn" type="button" onclick="createEntry()">Add</button>
	</div>
	
</body>

</html>