<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">

	<title>ListSharer</title>
	<meta name="description" content="Share A List">
	<meta name="author" content="Matthew S">
</head>

<body>
	<h1>List Sharer</h1>
	<h3>Create A Shared List</h3>
	<form action="/backend/createList.php" method="post">
		List Name:<br>
		<input type="text" name="name"><br>
		<input type="submit" value="Create!">
	</form>
</body>
</html>