<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">

	<title>List Sharer</title>
	<meta name="description" content="Share A List">
	<meta name="author" content="Matthew S">
	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<link rel="stylesheet" href="css/index.css">
	<link rel="stylesheet" href="css/overlay.css">
</head>

<body style="background-color:#5e5e5e;">
	
	<div class="overlay" style="display:none;">
		<div class="overlayCenterDiv" style="background-color:white;">
			<h3>List Name</h3>
			<input id="editTitle" type="text" value="Title">
			<button type="button" style="text-align:center; vertical-align:middle; font-size:1em;" onClick="">CREATE LIST</button>
		</div>
	</div>
	
	<div class="container">
		<div class="header">
			<h1> LISTSHARER.COM </h1>
		</div>
		
		<div>
			<form class="card" id="codeInput">
				<input id="listcode" type="text" placeholder="CODE" onkeydown = "if (event.keyCode == 13){event.preventDefault(); gotoList();}">
				<button id="gotoBtn" type="button" onClick="gotoList();"></button>
			</form>
			<form class="card">
				<button type="button" style="height:80%; width:95%; text-align:center; vertical-align:middle; font-size:8em;" onClick="">CREATE LIST</button>
			</form>
		</div>
		
		
	</div>
	
	<script>
		function gotoList(){
			window.location.href = "list.php?l="+ (document.getElementById('listcode').value).toUpperCase();
		}
	</script>
</body>
</html>