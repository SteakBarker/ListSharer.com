<?php
require_once("../../scripts/sqlConnect.php");
require_once("../../scripts/cleanData.php");
require_once("../../scripts/formatString.php");


//Input: code, entryID, title, desc, checked, tags
//Output: success, error (if success==0)
//error = 'error message'
if($_SERVER['REQUEST_METHOD'] === 'POST'){
	$listCode = formatString_Code($_POST["code"],8);
	$entryID = CleanData_Numeric($_POST["entryID"],11);
	$entryTitle = formatString_Title($_POST["title"],32);
	$entryDescription = formatString_Desc($_POST["desc"],128);
	$entryChecked = CleanData_Bool($_POST["checked"]);
	$entryTags = formatString_Tags($_POST["tags"],64);
	
	
	if(empty($listCode) || empty($entryID) || empty($entryTitle)){
		echo json_encode(array('success' => 0, 'error' => 'Invalid data'));
		exit();
	}
	
	$dbc = createDefaultConnection("listsharer");
	
	$listID;
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("SELECT ListID FROM lists WHERE Code=?");
	$stmt->bind_param("s",$listCode);
	if(!$stmt->execute()){echo json_encode(array('success' => 0, 'error' => 'An error occured')); exit();}
	$result = $stmt->get_result();
	$row = $result->fetch_array();
	$stmt->free_result(); $stmt->close();
	
	if(!$row){
		echo json_encode(array('success' => 0, 'error' => 'An error occured'));
		$dbc->close();
		exit();
	}else{
		$listID = $row["ListID"];
	}
	
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("UPDATE entries SET Title=?, Description=?, Checked=?, Tags=? WHERE EntryID=? AND ListID=?");
	$stmt->bind_param("ssisii",$entryTitle, $entryDescription, $entryChecked, $entryTags, $entryID, $listID);
	if(!$stmt->execute()){echo json_encode(array('success' => 0, 'error' => 'An error occured')); exit();}
	
	if($dbc->affected_rows>0){
		echo json_encode(array('success' => 1));
	}else{
		echo json_encode(array('success' => 0, 'error' => 'An error occured'));
	}
	
	$stmt->free_result(); $stmt->close();
	$dbc->close();
}
?>