<?php
require_once("../../scripts/sqlConnect.php");
require_once("../../scripts/cleanData.php");

if($_SERVER['REQUEST_METHOD'] === 'POST'){
	$listName = CleanData_Alphanumeric($_POST["name"],8);
	
	
	if(empty($listName)){
		echo 'An error occured';
		exit();
	}
	
	session_start();
	if($_SESSION["lastCreatedList"]>time()-60){
		error_log("User attemping to create lists too fast",0);
		echo "There was an error. Please try again shortly";
		exit();
	}
	$_SESSION["lastCreatedList"] = time();
	
	
	//First lets get a unique code.
	//Not the best method, but it works
	//Though admitidly the likelyhood of collion 
	
	$dbc = createDefaultConnection("listsharer");
	
	require_once("../../scripts/ranString.php");
	$listCode;
	
	//Lets check for collision
	while(true){
		$listCode = randomString_Alphacaps(5);
		
		$stmt = $dbc->stmt_init();
		$stmt->prepare("SELECT 1 ListID FROM lists WHERE Code=?");
		$stmt->bind_param("s",$listCode);
		if(!$stmt->execute()){echo 'An error occured'; exit();}
		$result = $stmt->get_result();
		$row = $result->fetch_array();
		$stmt->free_result(); $stmt->close();

		if(!$row){
			break;
			//There was no collision
		}
	}
	
	//Now lets add it to the list
	$stmt = $dbc->stmt_init();
	$stmt->prepare("INSERT INTO lists (ListID, Code, Name, LastViewed) VALUES (NULL, ?, ?, CURRENT_DATE)");
	$stmt->bind_param("ss",$listCode, $listName);
	if(!$stmt->execute()){echo 'An error occured'; exit();}
	$stmt->free_result(); $stmt->close();
	
	//Remember, the user can actually set these values to anyting they want. Its okay here though, because they'd just be doing it to themselves
	//$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http")."://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	//$url .= "list.php?l=".$listCode;
	
	$dbc->close();
}
?>
<html>
<head>
	<title>List Sharer</title>
</head>

<body>
	<div>
		<h3>Success</h3>
		<p> Your list code is: </p>
		<h4> <?php echo $listCode ?> </h4>
		<p> Share that code or keep it private! </p>
		<A HREF="../list.php?l=<?php echo $listCode?>">Go to your list now</A>
	</div>
</body>

</html>