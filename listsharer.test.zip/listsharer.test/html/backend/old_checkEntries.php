<?php
require_once("../../scripts/sqlConnect.php");
require_once("../../scripts/cleanData.php");

if($_SERVER['REQUEST_METHOD'] === 'POST'){
	$listCode = CleanData_Alphanumeric($_POST["code"],8);
	
	
	$entryIDs = CleanData_Numeric($_POST["entry"],11);
	//Notice how it's multiple.
	//The idea is the server waits 5 seconds (or until closing) to update the check. This way they can change their mind, or check multiple things off the list while easing strain on the server
	
	
	if(empty($listCode) || empty($entryID)){
		echo json_encode(array('success' => 0, 'error' => 'Invalid data'));
		exit();
	}
	
	$dbc = createDefaultConnection("listsharer");
	
	$listID;
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("SELECT ListID FROM lists WHERE Code=?");
	$stmt->bind_param("s",$listCode);
	if(!$stmt->execute()){echo json_encode(array('success' => 0, 'error' => 'An error occured')); exit();}
	$result = $stmt->get_result();
	$row = $result->fetch_array();
	$stmt->free_result(); $stmt->close();
	
	if(!$row){
		echo json_encode(array('success' => 0, 'error' => 'An error occured'));
		$dbc->close();
		exit();
	}else{
		$listID = $row["ListID"];
	}
	
}
?>