<?php
require_once("../../scripts/sqlConnect.php");
require_once("../../scripts/cleanData.php");


//Input: code, entryID, checked
//Output: success, error (if success==0)
//error = 'error message'
if($_SERVER['REQUEST_METHOD'] === 'POST'){
	$listCode = CleanData_Alphanumeric($_POST["code"],8);
	$entryID = CleanData_Numeric($_POST["entryID"],11);
	$entryChecked = CleanData_Bool($_POST["checked"]);
	
	
	if(empty($listCode) || empty($entryID)){
		echo json_encode(array('success' => 0, 'error' => 'Invalid data'));
		exit();
	}
	
	$dbc = createDefaultConnection("listsharer");
	
	$listID;
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("SELECT ListID FROM lists WHERE Code=?");
	$stmt->bind_param("s",$listCode);
	if(!$stmt->execute()){echo json_encode(array('success' => 0, 'error' => 'An error occured')); exit();}
	$result = $stmt->get_result();
	$row = $result->fetch_array();
	$stmt->free_result(); $stmt->close();
	
	if(!$row){
		echo json_encode(array('success' => 0, 'error' => 'An error occured'));
		$dbc->close();
		exit();
	}else{
		$listID = $row["ListID"];
	}
	
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("UPDATE entries SET Checked=? WHERE EntryID=? AND ListID=?");
	$stmt->bind_param("iii",$entryChecked, $entryID, $listID);
	if(!$stmt->execute()){echo json_encode(array('success' => 0, 'error' => 'An error occured')); exit();}
	
	if($dbc->affected_rows>0){
		echo json_encode(array('success' => 1));
	}else{
		echo json_encode(array('success' => 0, 'error' => 'An error occured'));
	}
	
	$stmt->free_result(); $stmt->close();
	$dbc->close();
}
?>