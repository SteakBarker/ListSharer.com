<?php
require_once("../../scripts/sqlConnect.php");
require_once("../../scripts/cleanData.php");
require_once("../../scripts/formatString.php");

class Entry{
	public $entryID;
	public $title;
	public $description;
	public $dateCreated;
	public $checked;
	public $tags;	
}


//Input: code, title, desc, quant, tags
//Output: success, error/entry
//error = 'error message'
//entry = entryID, title, desc, quant, dateCreated, checked, tags
if($_SERVER['REQUEST_METHOD'] === 'POST'){
	$listCode = formatString_Code($_POST["code"],8);
	$entryTitle = formatString_Title($_POST["title"],32);
	$entryDescription = formatString_Desc($_POST["desc"],128);
	$entryTags = formatString_Tags($_POST["tags"],64);
	
	if(empty($listCode) || empty($entryTitle)){
		echo json_encode(array('success' => 0, 'error' => 'Invalid data'));
		exit();
	}
	
	session_start();
	if($_SESSION["lastCreatedEntry"]>time()-2){
		error_log("User attemping to create entries too fast",0);
		echo json_encode(array('success' => 0, 'error' => 'There was an error. Please try again shortly'));
		exit();
	}
	$_SESSION["lastCreatedEntry"] = time();
	
	$dbc = createDefaultConnection("listsharer");
	
	$listID;
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("SELECT ListID FROM lists WHERE Code=?");
	$stmt->bind_param("s",$listCode);
	if(!$stmt->execute()){echo json_encode(array('success' => 0, 'error' => 'An error occured')); exit();}
	$result = $stmt->get_result();
	$row = $result->fetch_array();
	$stmt->free_result(); $stmt->close();
	
	if(!$row){
		echo json_encode(array('success' => 0, 'error' => 'An error occured'));
		$dbc->close();
		exit();
	}else{
		$listID = $row["ListID"];
	}
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("INSERT INTO entries (EntryID, Title, Description, DateCreated, Checked, Tags, ListID) VALUES (NULL, ?, ?, CURRENT_DATE, 0, ?, ?)");
	$stmt->bind_param("sssi",$entryTitle, $entryDescription, $entryTags, $listID);
	if($stmt->execute()){
		$entry = new Entry();
		$entry->entryID = $dbc->insert_id;
		$entry->title = $entryTitle;
		$entry->desc = $entryDescription;
		$entry->dateCreated = date_default_timezone_get(); //This doesn't adjust for client time zone
		$entry->checked = 0;
		$entry->tags = $entryTags;
		
		$arr = array('success' => 1, 'entry' => $entry);
		echo json_encode($arr);
		
	}else{
		echo json_encode(array('success' => 0, 'error' => 'An error occured'));
		exit();
	}
	
	$stmt->close();
	$dbc->close();
}
?>