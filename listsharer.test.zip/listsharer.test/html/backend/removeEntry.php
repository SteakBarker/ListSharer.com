<?php
require_once("../../scripts/sqlConnect.php");
require_once("../../scripts/cleanData.php");

if($_SERVER['REQUEST_METHOD'] === 'POST'){
	$listCode = CleanData_Alphanumeric($_POST["code"],8);
	$entryID = CleanData_Numeric($_POST["entryID"],11);
	
	
	if(empty($listCode) || empty($entryID)){
		echo json_encode(array('success' => 0, 'error' => 'Invalid data'));
		exit();
	}
	
	
	$dbc = createDefaultConnection("listsharer");
	
	$listID = 0;
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("SELECT ListID FROM lists WHERE Code=?");
	$stmt->bind_param("s",$listCode);
	if(!$stmt->execute()){echo json_encode(array('success' => 0, 'error' => 'An error occured')); exit();}
	$result = $stmt->get_result();
	$row = $result->fetch_array();
	$stmt->free_result(); $stmt->close();
	
	if(!$row){
		echo json_encode(array('success' => 0, 'error' => 'An error occured'));
		$dbc->close();
		exit();
	}else{
		$listID = $row["ListID"];
	}
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("DELETE FROM entries WHERE EntryID=? AND ListID=?");
	$stmt->bind_param("ii",$entryID, $listID);
	if(!$stmt->execute()){echo json_encode(array('success' => 0, 'error' => 'An error occured')); exit();}
	
	if($dbc->affected_rows>0){
		echo json_encode(array('success' => 1));
	}else{
		echo json_encode(array('success' => 0, 'error' => 'An error occured'));
		exit();
	}
	
	$stmt->free_result(); $stmt->close();
	$dbc->close();
}
?>