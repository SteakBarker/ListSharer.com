<?php
require_once("../../scripts/sqlConnect.php");
require_once("../../scripts/cleanData.php");

class Entry{
	public $entryID;
	public $title;
	public $description;
	public $dateCreated;
	public $checked;
	public $tags;	
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
	$code = CleanData_Alphanumeric($_POST["code"],8);
	if(empty($code)){
		echo json_encode(array('success' => 0, 'error' => 'Invalid data'));
		exit();
	}
	
	$dbc = createDefaultConnection("listsharer");
	$listID;
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("SELECT ListID FROM lists WHERE Code=?");
	$stmt->bind_param("s",$code);
	$stmt->execute();
	$result = $stmt->get_result();
	$row = $result->fetch_array();
	$stmt->free_result(); $stmt->close();
	
	if(!$row){
		echo json_encode(array('success' => 0, 'error' => 'An error occured'));
		$dbc->close();$stmt->close();
		exit();
	}else{
		$listID = $row["ListID"];
	}
	
	$entries = [];
	
	$stmt = $dbc->stmt_init();
	$stmt->prepare("SELECT * FROM entries WHERE ListID=?");
	$stmt->bind_param("i",$listID);
	$stmt->execute();
	$entryResult = $stmt->get_result();
		
	while ($entryRow = $entryResult->fetch_array()){
		
		if(!$entryRow){
			echo json_encode(array('success' => 0, 'error' => 'An error occured'));
			$dbc->close();$stmt->close();
			exit();
		}
		$entry = new Entry();
		$entry->entryID = $entryRow["EntryID"];
		$entry->title = $entryRow["Title"];
		$entry->description = $entryRow["Description"];
		$entry->dateCreated = $entryRow["DateCreated"];
		$entry->checked = $entryRow["Checked"];
		$entry->tags = $entryRow["Tags"];
		
		array_push($entries, $entry);
	}
	$stmt->free_result(); $stmt->close();
	
	$arr = array('success' => 1, 'entries' => $entries);
	echo json_encode($arr);
	$dbc->close();
}else{
	exit("Invalid request");
}
?>