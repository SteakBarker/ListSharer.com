function checkEntry(id){ //Remember id is an index to allEntries
	allEntries[id]["checked"] = (allEntries[id]["checked"] ? 0 : 1); //If checked, uncheck. if unchecked, check
	
	ajaxCheckEntry(listcode, allEntries[id], function(output){
		var results = JSON.parse(output);
		
		if(results["success"] == 0){
			alert(results["error"]);
			return;
		}
		sortList();
	});
}

function ajaxCheckEntry(code, entry, handleData) {
	$.ajax({
		url:"/backend/checkEntry.php",
		type:'POST',
		data:
		{
			code:code,
			entryID:entry["id"],
			checked:entry["checked"],
		},beforeSend: function() {
			$("#loadingIcon").show();
		},success:function(data) {
			$("#loadingIcon").hide();
			handleData(data);
		},error: function(){
			$("#loadingIcon").hide();
			alert("Request Failed");
		},
		timeout: 10000
	});
}