var allEntries = []; //id, title, checked, tags[], desc, date
	//entries will be refered by their index position in this script!!!
var allTags = []; //name (The tag ID will be its index
var selectedTags = []; //allTags indexes that will be shown

function sortList(){
	$("#listContainer").empty();  //Removes all entries
	var list = [];
	
	var i;
	for (i = 0; i < allEntries.length; i++) {
		if(selectedTags.length>0){ //Okay, we need to make sure this is part of the selectedTags
			 var j;
			 for(j = 0; j < selectedTags.length; j++){
				 if(allEntries[i].tags.includes(selectedTags[j])){
					list.push(i);
					break;
				 }
			 }
		}else{
			list.push(i);
		}
	}
	
	list.sort(entrySortFunc);
	
	var i;
	for (i = 0; i < list.length; i++) {
		addEntryDiv(list[i]);
	}
	
	addAllTags();
}
function entrySortFunc(a, b){
	a = allEntries[a];
	b = allEntries[b];
	
	if(a.checked && !b.checked){
		return 1; //Checked items go to the bottom
	}else if(!a.checked && b.checked){
		return -1; //Checked items go to the bottom
	}
	
	if(a.date > b.date) {return -1;}
	else if (a.date < b.date) {return 1;}
	
	return 0;
}
