//Returns the values from the add an entry div.
//Will look like this: //title, tags, desc
function getAddEntryDivValues(){
		return {
			title:$("#EntryAddTitle").val(),
			tags:$("#EntryAddTags").val(),
			desc:$("#EntryAddDesc").val(),
	};
}
function clearAddEntryDiv(){
	$("#EntryAddTitle").val("");
	$("#EntryAddTags").val("");
	$("#EntryAddDesc").val("");
}

function createEntry(){
	
	//Send entry to server
	//If added sucsesfully, clear add entry div
	//If failed do not clear; return error
	entry = getAddEntryDivValues();
	
	ajaxAddEntry(listcode, entry, function(output){
		var results = JSON.parse(output);
		
		if(results["success"] == 0){
			alert(results["error"]);
			return;
		}
		var entry = results["entry"];
		
		addEntry(entry["entryID"], entry["title"], entry["checked"], entry["tags"], entry["desc"], entry["dateCreated"]);
		clearAddEntryDiv();
		
		addAllTags();
		sortList();
	});
}

function ajaxAddEntry(code, entry, handleData) {
	$.ajax({
		url:"/backend/addEntry.php",
		type:'POST',
		data:
		{
			code:code,
			title:entry["title"],
			desc:entry["desc"],
			tags:entry["tags"]
		},beforeSend: function() {
			$("#loadingIcon").show();
		},success:function(data) {
			$("#loadingIcon").hide();
			handleData(data);
		},error: function(){
			$("#loadingIcon").hide();
			alert("Request Failed");
		},
		timeout: 10000
	});
}