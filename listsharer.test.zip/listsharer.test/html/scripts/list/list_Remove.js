function removeEntry(id){
	$('#Entry'+id+'BtnRemove').html('Confirm?');
	$('#Entry'+id+'BtnRemove').click(function(){
		
		ajaxRemoverEntry(listcode, id, function(output){
		var results = JSON.parse(output);
		
		if(results["success"] == 0){
			alert(results["error"]);
			return;
		}
		allEntries.splice(id,1);
		sortList();
		});
	});
}
function ajaxRemoverEntry(code, entryIndex, handleData) {
	$.ajax({
		url:"/backend/removeEntry.php",
		type:'POST',
		data:
		{
			code:code,
			entryID:allEntries[entryIndex]["id"]
		},beforeSend: function() {
			$("#loadingIcon").show();
			$('Entry'+entryIndex+'Div').hide();
		},success:function(data) {
			$("#loadingIcon").hide();
			handleData(data); 
		},error: function(){
			$("#loadingIcon").hide();
			$('Entry'+entryIndex+'Div').show();
			alert("Request Failed");
		},
		timeout: 10000
	});
}