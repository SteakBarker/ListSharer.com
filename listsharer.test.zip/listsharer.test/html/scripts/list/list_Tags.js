function addTagDiv(to,tagIndex){
	var elm = '<div class="tag" onclick="sortTags('+tagIndex+')">'+allTags[tagIndex]+'</div>';
	$(to).append(elm);
}

/**
* This function will check if the tag exists and return its array index. If it does not exist, it will create it and return the index
* @param {string} Name the name of the tag
* @return {int} index The index of the tag in the allTags[] array
*/
function checkTag(name){
	if(typeof allTags !== 'undefined' && allTags.length>0){
		var i;
		for (i = 0; i < allTags.length; i++) {
			if(allTags[i]===name){
				return i;
			}
		}
	}
	//Tag was not found. Would have returned if found
	allTags.push(name);
	return allTags.length-1;
}

//When you click a tag this is called.
// A)That tag you clicked was already on your filter, it will remove it from our filter
// B)The tag was not on the filter, it will add it to the filter
//It then resorts our list based on our new filter
function sortTags(tagIndex){
	var i;
	for(i = 0; i < selectedTags.length; i++){
		if(selectedTags[i]===tagIndex){
			selectedTags.splice(i, 1);
			addSelectedTags();
			sortList();
			return;
		}
	}
	selectedTags.push(tagIndex);
	addSelectedTags();
	sortList();
}

function addSelectedTags(){
	$("#selectedTags").empty();
	var i;
	for(i = 0; i < selectedTags.length; i++){
		addTagDiv("#selectedTags", selectedTags[i]);
	}
}
function addAllTags(){
	$("#allTags").empty();
	var i;
	for(i = 0; i < allTags.length; i++){
		if(!selectedTags.includes(i)){
			addTagDiv("#allTags", i);
		}
	}
}