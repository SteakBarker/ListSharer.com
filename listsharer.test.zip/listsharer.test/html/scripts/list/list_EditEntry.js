var editedEntry; //This will be an index to all entries. It will be the one that we are currently editing


//Returns the values from the add an entry div.
//Will look like this: //title, tags, desc, checked
function getEditEntryDivValues(){
		return {
			title:$("#editTitle").val(),
			tags:$("#editTags").val(),
			desc:$("#editDesc").val(),
			checked:$("#editChecked").prop('checked'),
	}; 
}

function editEntry(id){
	editedEntry = id; //Remember ID in this case is the index to allEntries
	
	$("#editOverlay").show();
	
	e = allEntries[id]; //allEntries is stored in list.js
	
	$('#editTitle').val(e["title"]);
	$('#editDesc').val(e["desc"]);
	
	var tagsString = "";
	var i;
	for (i = 0; i < e["tags"].length; i++) {
		if(i==e["tags"].length-1){
			tagsString += allTags[e["tags"][i]];
		}else{
			tagsString += allTags[e["tags"][i]] +",";
		}
	}
	$('#editTags').val(tagsString);
}


function cancelEdit(){
	///TODO: Add confirm dialog
	$("#editOverlay").hide();
}
function  confirmEdit(){
	var newValues = getEditEntryDivValues();
	
	allEntries[editedEntry]["title"] = newValues["title"];
	allEntries[editedEntry]["tags"] = newValues["tags"];
	allEntries[editedEntry]["desc"] = newValues["desc"];
	allEntries[editedEntry]["checked"] = (newValues["checked"] ? 1 : 0);
	
	ajaxEditEntry(listcode, allEntries[editedEntry], function(output){
		var results = JSON.parse(output);
		
		if(results["success"] == 0){
			alert(results["error"]);
			return;
		}
		
		setEntryTags(editedEntry, allEntries[editedEntry]["tags"]);
		sortList();
		$("#editOverlay").hide();
	});
}

//Entry = id(EntryID -- not allEntriesIndex), title, desc, quant, checked, tags(String form)
function ajaxEditEntry(code, entry, handleData) {
	$.ajax({
		url:"/backend/editEntry.php",
		type:'POST',
		data:
		{
			code:code,
			entryID:entry["id"],
			title:entry["title"],
			desc:entry["desc"],
			checked:entry["checked"],
			tags:entry["tags"]
			
		},beforeSend: function() {
			$("#loading").show();
		},success:function(data) {
			$("#loading").hide();
			handleData(data);
		},error: function(){
			$("#loading").hide();
			alert("Request Failed");
		},
		timeout: 10000
	});
}