
///This function loads our list, adds all our entries to the arrays, create entryDivs for them, adds the tags, and then sorts our list
//Remember, all our arrays are held in list.js
function loadList(){
	ajaxLoadList(listcode, function(output){
		var results = JSON.parse(output);
		
		if(results["success"] == 0 || !results["entries"]){
			alert(results["error"]);
			return;
		}
		var entries = results["entries"];
		var i;
		for (i = 0; i < entries.length; i++) {
			//id,title,checked,tags,desc,date
			addEntry(results["entries"][i]["entryID"],results["entries"][i]["title"],results["entries"][i]["checked"],results["entries"][i]["tags"],results["entries"][i]["description"],results["entries"][i]["dateCreated"] );
		}
		
		addAllTags();
		sortList();
	});
}

/**
* Will create an div in the listContainer.
* @param {int} allEntriesIndex The index the entry is in allEntries
* @return {element} Will return the element created
*/
function addEntryDiv(allEntriesIndex){
	
	var e = allEntries[allEntriesIndex];
	var elm = '<div class="entryDiv" id="Entry'+allEntriesIndex+'Div">';
	elm += '<input class="entryCheckbox" id="Entry'+allEntriesIndex+'Checked" type="checkbox" '+(e.checked?"checked":"")+' onclick="checkEntry('+allEntriesIndex+');">';
	elm += '<h4 class="entryTitle" id="Entry'+allEntriesIndex+'Title">'+e.title+'</h4>';
	
	if(typeof e.tags !== 'undefined' && e.tags.length>0){
		var i;
		for (i = 0; i < e.tags.length; i++) {
			elm += '<div class="tag" id="Entry'+allEntriesIndex+'TagTest" onclick="sortTags('+e.tags[i]+')">'+allTags[e.tags[i]]+'</div>';
		}
	}
	
	///TODO: Make sure description is not null
	elm+= '<p class="entryDesc" id="Entry'+allEntriesIndex+'Desc">'+e.desc+'</p>';
	
	elm+='<div class="entryButtonDiv"><button class="entryButton" id="Entry'+allEntriesIndex+'BtnEdit" type="button" onclick="editEntry('+allEntriesIndex+');">Edit</button>';
	elm+= '<button class="entryButton" id="Entry'+allEntriesIndex+'BtnRemove" type="button" onclick="removeEntry('+allEntriesIndex+');">Remove</button></div>';

	$("#listContainer").append(elm);
	
	return document.getElementById('Entry'+allEntriesIndex+'Div');
}

///Takes an allEntriesIndex and tags in string from ("Tag1,Tag2,Tag3")
///And will create the misisng tags (If a tag doesn't exist, it will add it to allTags.
///Then it will set the entry["tags"] to be an array of indexes to allTags
function setEntryTags(id, tags){
	
	var entryTags = [];
	if(typeof tags !== 'undefined' && tags.length>0){
		tags = tags.split(','); ////Remember, tags is going to look like this: 'tag1,tag2,tag3
		var i;
		for (i = 0; i < tags.length; i++) {
			if(tags[i].length<=0){continue;} //Don't worry about empty tags; probably and extra coma
			entryTags.push(checkTag(tags[i]));
		}
	}
	
	allEntries[id]["tags"] = entryTags;
}

function addEntry(id,title,checked,tags,desc,date){
	//Create entry and add to allEntries
	//This DOES NOT add the entryDiv.
	//The creating of entry divs is done in sortList.
	//This will however add to allTags if need be, but will not add the tags
	//Call sortList() && addAllTags() after adding all your new entries
	
	var entry = {
		id:id,
		title:title,
		checked:checked,
		tags:'',
		desc:desc,
		date:date,
	};
	
	allEntries.push(entry);
	setEntryTags(allEntries.length-1, tags);
}

function ajaxLoadList(code, handleData) {
	$.ajax({
		url:"/backend/getEntries.php",
		type:'POST',
		data:
		{
			code:code,
		},beforeSend: function() {
			$("#loading").show();
		},success:function(data) {
			$("#loading").hide();
			handleData(data); 
		},error: function(){
			$("#loading").hide();
			alert("Request Failed");
		},
		timeout: 10000
	});
}

///This is called when the page loads
$( document ).ready(function() {
    loadList();
});