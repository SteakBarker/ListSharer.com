function showTip(elementName){
	$("#"+elementName).show();
}
function hideTip(elementName){
	$("#"+elementName).hide();
}