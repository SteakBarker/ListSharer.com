<?php
require_once("cleanData.php");

///Will trim white space (Spaces&Tabs) at the begining and end of a string; but NOT in between
function formatString_TrimWhitespace($string){
	return preg_replace('/^[ \t\n\r\0\x0B]+/', "", preg_replace('/[ \t\n\r\0\x0B]+$/', "", $string));
}

///Will trim white space (Spaces&Tabs) in between commas. Example: "Test, Test, Test Me" ---> "Test,Test,Test Me"
function formatString_TrimCommaWhitespace($string){
	return preg_replace('/,[ \t\n\r\0\x0B]+/', ",", $string);
}

///Site specific ///
//We do it this way because it makes it much easier to make changes across the whole site

function formatString_Title($string){
	//return formatString_TrimWhitespace(CleanData_Text($string,32));
	return CleanData_Text($string,32);
}
function formatString_Tags($string){
	return formatString_TrimCommaWhitespace(formatString_TrimWhitespace(CleanData_Text($string,64)));
}
function formatString_Desc($string){
	return CleanData_Text($string,128);
}
function formatString_Code($string){
	return CleanData_Alphanumeric($string,8);
}

?>