﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiteConverter {
	class Program {
		static void Main(string[] args) {

			string path = Directory.GetCurrentDirectory();

			SQLQueryConverter converter = new SQLQueryConverter("$sqlObj");

			Console.WriteLine("File To Convert:");
			Console.WriteLine("A backup will be stored at " + path + "\\SQLConverter\\Backup\\");

			while (true) {
				Console.Write(path + "\\: ");

				string input = Console.ReadLine();
				string text = "";


				//Console.WriteLine(converter.AutoConvert(input) + "\n");
				//continue;

				try {
					text = File.ReadAllText(path + "/" + input);
				} catch (Exception err) {
					Console.WriteLine("There was an error reading the file: " + err.Message);
					continue;
				}

				System.IO.Directory.CreateDirectory(path + "\\SQLConverter\\Backup\\"); //We don't have to check if it is created, the manual says

				try {
					if (!File.Exists(path + "\\SQLConverter\\Backup\\" + input)) {
						File.WriteAllText(path + "\\SQLConverter\\Backup\\" + input, text); //Just make a backup
					} else {
						Console.WriteLine("Warning: Backup file already exists. NOT overwritting.");
					}
				} catch (Exception err) {
					Console.WriteLine("There was an error making a backup file: " + err.Message);
					continue;
				}

				text = converter.AutoConvert(text);

				try {
					File.WriteAllText(path + "/" + input, text);
				}catch(Exception err) {
					Console.WriteLine("There was an error saving the file: " + err.Message);
					continue;
				}

				Console.WriteLine("Done. "+converter.LastChanges+" changes");
			}
		}
	}
}
