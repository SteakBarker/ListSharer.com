﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SiteConverter {

	class SQLQueryConverter {
		[Flags]
		private enum ConvertType {
			None,
			Query,
			FetchRow,
			FreeResults,
			NumRow
		}


		string sqlObjName;
		int lastChanges = 0;
		public int LastChanges { get => lastChanges;}

		public SQLQueryConverter(string sqlObjName) {
			this.sqlObjName = sqlObjName;
		}

		public string AutoConvert(string str) {

			StringBuilder finishedString = new StringBuilder();
			string currentString = str; //This really ins't needed

			int changes = 0;
			while (true) {
				ConvertType convertType = ConvertType.None;
				int i = 2147483647; //This is the max int value. 
				int tmpi = 2147483647;

				if ((tmpi = currentString.IndexOf("sql_query")) > -1) {
					convertType = ConvertType.Query;
					i = tmpi; //This might not make sense, but we do this so it does which ever one comes FIRST in the text
				} if ((tmpi = currentString.IndexOf("sql_free_result")) > -1 && tmpi<i) {
					convertType = ConvertType.FreeResults;
					i = tmpi;
				} if ((tmpi = currentString.IndexOf("sql_fetch_row")) > -1 && tmpi<i) {
					convertType = ConvertType.FetchRow;
					i = tmpi;
				} if ((tmpi = currentString.IndexOf("sql_num_rows")) > -1 && tmpi < i) {
					convertType = ConvertType.NumRow;
					i = tmpi;
				}

				if (convertType == ConvertType.None) { //If we didn't find anything, we must be done
					this.lastChanges = changes;
					finishedString.Append(currentString);
					return MakeChangeLog(changes)+finishedString.ToString();
				}
				 //i = start of method name
				 //j = closinhg parenthesee of that method

				finishedString.Append(currentString.Substring(0, i)); //Add everything before our method to the finished string. Substring atually takes a length but because we always start on 0 it doesnt matter
				currentString = currentString.Substring(i, currentString.Length - i); //Removes everything before the start of our method start

				int j = GetClosingParentheses(currentString);

				string method = currentString.Substring(0, j); //again we always start on zero so the fact substring uses length doesnt matter

				currentString = currentString.Substring(j, currentString.Length - j); //Removes everything after the end of our method

				finishedString.Append(Convert(convertType, method));

				changes++;
			}
		}

		/// <summary>
		/// Will take a string, and tell you when the next occuring parentheses closses
		/// Example: "Hello("Hi") > 1 ? 1 : 2;" will return 10
		/// </summary>
		int GetClosingParentheses(string str) {
			int firstParen = str.IndexOf('(');
			if(firstParen == -1) { throw new Exception("No first parentheses found!"); }

			int j = 0;
			for(int i=firstParen; i<str.Length; i++) {
				if (str[i].Equals('(')) {
					j++;
				}else if (str[i].Equals(')')) {
					j--;
				}
				if (j == 0) {
					return i+1; //+1 so it gets the last parentheses. Without it Hi() would return Hi(
				}

			}
			throw new Exception("Unbalanced parentheses! Off by " + j);
		}


		string Convert(ConvertType type, string str) {
			/*
			First, we need to get just the parametes
			sql_fetch_row($resultmt_con, $dbi) -> $resultmt_con, $dbi
			Turn the parametes into an array
			Pass the values to the converter method
			 */

			int trimStart = str.IndexOf('(');
			str = str.Substring(trimStart + 1, (str.Length-trimStart)-1); //+1 to remove the first (. -1 to remove the last character which will always be the )

			string[] param = SplitCommas(str);

			if (type == ConvertType.Query) {
				return ConvertQuery(param);
			}else if(type == ConvertType.FreeResults) {
				return ConvertFreeResult(param);
			}else if(type == ConvertType.FetchRow) {
				return ConvertFetchRow(param);
			} else if (type == ConvertType.NumRow) {
				return ConvertNumRow(param);
			} else {
				return "";
			}
		}

		//"Hello","Hi" -> s[0]="Hello" s[1]="Hi"
		string[] SplitCommas(string param) {
			//Regex fucks my mind.
			//,(?=(?:[^"]*'[^"]*")*[^"]*$) - https://stackoverflow.com/questions/3147836/c-sharp-regex-split-commas-outside-quotes
			//return param.Split(',');

			return Regex.Split(param, ",(?=(?:[^\"]* '[^\"]*\")*[^\"]*$)");
		}

		string ConvertQuery(string[] param) {

			string str = param[0];

			string paramList = "";
			string types = "";


			//str = str.Replace('"', '\0'); //This is easier than removing the first and last thing
			str = str.Substring(1, str.Length-2); //The first and last are always quotes. We don't want them

			var regex = new Regex(@"(?<=\$)(\w+)");

			foreach(Match m in regex.Matches(str)) {

				if (paramList == "") { paramList += "$" + m.Value; }
				else { paramList += ", $" + m.Value; }

				//str = str.Replace( ("$" + m.Value) , "?");
				Regex replaceReg = new Regex(Regex.Escape(("$" + m.Value))); //This just replaces the FRIST occurance
				str = replaceReg.Replace(str, "?", 1);

				types += "s"; //This will need to be changed manually by the user. The computer has no way of knowing what type it is
			}

			str = str.Replace("'?'", "?");

			return sqlObjName + "->preparedQuery(\"" + str + "\", \"" + types + "\", array(" + paramList + "))";
		}

		string ConvertFreeResult(string[] param) {
			return param[0]+"->free_result()";
		}

		string ConvertFetchRow(string[] param) {
			return param[0]+"->fetch_row()";
		}
		string ConvertNumRow(string[] param) {
			return param[0] + "->num_rows";
		}


		private string MakeChangeLog(int numberOfChanges) {
			return "//This script was run through a script to convert to prepared statements"
				+ "\n//Created by Matthew Shewmaker"
				+ "\n//" + numberOfChanges + " changes. - " + DateTime.Today + "\n\n";

		}
	}
}
